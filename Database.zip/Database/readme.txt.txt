Database details are present inside enumless query
