use vldms;
create table user_table(user_id varchar(20) primary key not null, password varchar(20) not null,
 name varchar(20) not null, type_of_user varchar(30) not null,email_id varchar(20), 
 mobile_no int(10));
-- drop table user_table; 
insert into user_table values('M101','m123','Reena','MoHFW_Officer','r@123',8978);
insert into user_table values('P101','p123','Jitendra','Production_Officer','jit@123',9978);
insert into user_table values('S101','s123','Mayuri','State_Store_Officer','myur@123',1978);
insert into user_table values('D101','d123','Aabha','District_Store_Officer','abha@123',0979);
insert into user_table values('V101','v123','Vibha','Vaccination_Officer','vib123',19790);

select * from user_table;
delete from user_table where user_id ='D102';
select user_id,name,type_of_user from user_table where user_id='M101'
  and password='m123' and type_of_user='MoHFW_Officer';
  
  
  
  
  
  create table order_detail_table( order_id int(20) primary key AUTO_INCREMENT,
  ordered_by varchar(20) not null,
  FOREIGN KEY(ordered_by)  REFERENCES user_table(user_id) on delete cascade ,
  date_of_order datetime not null,
  type_of_vaccine varchar(30) not null,
  Company_Name varchar(30)  not null,
  Destination_State varchar(30)  not null,

State_regional_office varchar(30)  not null,

 Quantity_of_vaccine int not null,
Manufacturer_Location varchar(30)  not null,
upadted_Quantity tinyint(1) 
);

-- drop table order_detail_table;

select * from order_detail_table;
delete from order_detail_table;

insert into order_detail_table values 
(null,'M101',sysdate(),'Covishield','Serum',
 'Chhattisgarh','Raipur',600000,'Pune',0);
 
 
 
 create table order_status_table(order_id int not null primary key,
FOREIGN KEY(order_id) REFERENCES order_detail_table(order_id)on delete cascade,
order_Status_of_Approval varchar(30),
comment_text text ,
date_of_Update_Status datetime not null,
action_performed_by varchar(20) ,
FOREIGN KEY(action_performed_by)  REFERENCES user_table(user_id)on delete cascade) ;


-- drop table order_status_table;
select * from order_status_table;
-- delete from order_status_table where order_id=19;
insert into order_status_table values(
 1,'Pending','waiting for approval ',sysdate(),
null
 );
 create table distribution_to_district_table(order_id int(20) not null ,
  FOREIGN KEY(order_id) REFERENCES order_detail_table(order_id),
batch_no int primary key AUTO_INCREMENT,
district_name varchar(30) not null,
distribution_Date datetime not null,
issue_Vaccine_quantity int not null
  );
  
 
  select * from distribution_to_district_table;
-- delete from distribution_to_district_table;
  
 -- drop table distribution_to_district_table;
  
  select issue_Vaccine_quantity from distribution_to_district_table where order_id=3;
  
  
   
  
 create table order_dispatch_table(order_id int(20) primary key not null,
  FOREIGN KEY(order_id)  REFERENCES order_detail_table(order_id) on delete cascade, 
  manufacture_location varchar(30) not null,
 Destination_State varchar(30) not null,
 Destination_address varchar(30) not null,
 manufacture_date_of_vaccine date not null,
 last_update_date datetime not null,
 dispatch_date datetime not null,
 Dispatched_by varchar(20) not null , FOREIGN KEY(Dispatched_by) 
 REFERENCES user_table(user_id) on delete cascade,
 Received_by varchar(20),FOREIGN KEY(Received_by)
 REFERENCES user_table(user_id) on delete cascade
  );
  
drop table order_dispatch_table;

select * from order_dispatch_table;
create table district_dispatch_table(  
   batch_no int(20) primary key not null  ,
  FOREIGN KEY(Batch_no)  REFERENCES distribution_to_district_table(Batch_no)  on delete cascade,
  source_address varchar(30) not null,
  destination_address varchar(30)not null,
  last_update_date datetime not null,
  dispatch_date datetime not null,
 dispatched_by varchar(20) not null , FOREIGN KEY(Dispatched_by) 
 REFERENCES user_table(user_id) ,
received_by varchar(20)  , FOREIGN KEY(Received_by)
 REFERENCES user_table(user_id)
  );
  
   drop table district_dispatch_table;
  
  select * from district_dispatch_table;
  

-- drop table vaccination_office_distribution;
create table vaccination_office_distribution(order_id int not null ,foreign key (order_id ) 
REFERENCES order_detail_table(order_id), batch_no int(20) not null,foreign key (batch_no)
REFERENCES distribution_to_district_table(batch_no),
consignment_no int(20) not null primary key AUTO_INCREMENT,
vacc_office_location varchar(30) not null ,
issue_vaccine_quantity int not null,
distribution_date datetime not null);
ALTER TABLE  vaccination_office_distribution AUTO_INCREMENT=100;
describe vaccination_office_distribution;
insert into vaccination_office_distribution values(1,1,null,'Balod_PHC',1000,now());
select * from vaccination_office_distribution;


drop table  VO_dispatch_table;
create table VO_dispatch_table(order_id int not null ,
foreign key (order_id ) REFERENCES order_detail_table(order_id),
batch_no int(20) not null,
foreign key (batch_no) REFERENCES distribution_to_district_table(batch_no),
consignment_no int(20) not null primary key,
foreign key (consignment_no) REFERENCES vaccination_office_distribution(consignment_no),
source_addresss varchar(30) not null,destination_address varchar(30) not null,
last_update_date datetime not null,
dispatch_date datetime not null,
dispatched_by varchar(20) not null , FOREIGN KEY(dispatched_by) REFERENCES user_table(user_id) ,
received_by varchar(20)  , FOREIGN KEY(received_by) REFERENCES user_table(user_id));
describe VO_dispatch_table;
insert into VO_dispatch_table values(1,1,100,'Balod','Balod_PHC',now(),now(),'D101',null);

select * from VO_dispatch_table;


drop table consignment_usage_table;
describe consignment_usage_table;
create table consignment_usage_table(consignment_no int(20) not null ,
foreign key (consignment_no) 
REFERENCES vaccination_office_distribution(consignment_no),total_quantity int not null,
consumed int not null,damaged int not null,remaining int not null, date datetime not null);
insert into consignment_usage_table values (100,1000,800,20,180,now());
select * from consignment_usage_table;
