import axios from "axios";

const API_URL = "http://localhost:8080/api/v1/";




export async function dispatchOrder(data) {
  try {
    const options = 
    {
        params: 
        { 
            order_id: data.order_id,
            manufacture_date_of_vaccine : data.manufacture_date_of_vaccine,
            dispatched_by : data.dispatched_by
        }
    }
    
    console.log(options)
    const result= await axios.get(`${API_URL}dispatchorder`,options);

    return await result
  } catch (e) {
    throw e;
  }
}

export async function rejectOrder(data) {
  try {
    const options = 
    {
        params: 
        { 
            order_id: data.order_id,
            action_performed_by:data.action_performed_by,
            
        }
    }
    
    console.log(options)
    const result= await axios.get(`${API_URL}rejecttheorder`,options);

    return await result
  } catch (e) {
    throw e;
  }
}
export async function approveOrder(data) {
  try {
    const options = 
    {
        params: 
        { 
            order_id: data.order_id,
            ordered_by:data.ordered_by,
            
        }
    }
    
    console.log(options)
    const result= await axios.get(`${API_URL}approvetheorder`,options);

    return await result
  } catch (e) {
    throw e;
  }
}
export async function cancelOrder(data) {
  try {
    const options = 
    {
        params: 
        { 
            order_id: data.order_id,
            ordered_by:data.ordered_by,
            
        }
    }
    
    console.log(options)
    const result= await axios.get(`${API_URL}canceltheorder`,options);

    return await result
  } catch (e) {
    throw e;
  }
}

export async function updateOrder(data) {
  try {
    const options = 
    {
        params: 
        { 
            order_id: data.order_id,
            ordered_by:data.ordered_by,
            quantity_of_vaccine :data.quantity_of_vaccine
        }
    }
    
    console.log(options)
    const result= await axios.get(`${API_URL}updateorder`,options);

    return await result
  } catch (e) {
    throw e;
  }
}


export async function registeringUser(data) {
  try 
  {
    const result= await axios.put(`${API_URL}add`,data);
    return await result
  } catch (e) {
    throw e;
  }
}


export async function CreatingOrder(data) {
  try 
  {
    const result= await axios.put(`${API_URL}createOrder`,data);
    return await result
  } catch (e) {
    throw e;
  }
}
export async function checkuser(data) 
{
  try {
    const options = 
    {
        params: 
        { 
            user_id: data.user_id,
            password:data.password,
            type_of_user:data.type_of_user
        }
    }
    const res=await axios.get(`${API_URL}userlogin`, options);
    return await res;
  } catch (e) {
    throw e;
  }
}
export async function acknowrder(data) 
{
  try {
    const options = 
    {
        params: 
        { 
            
          order_id: data.order_id,
          received_by:data.received_by,
          quantity_of_vaccine :data.quantity_of_vaccine,
          manufacture_date_of_vaccine : data.manufacture_date_of_vaccine,
          company_Name : data.company_Name
          
        }
    }
    const res=await axios.get(`${API_URL}ackworder`, options);
    return await res;
  } catch (e) {
    throw e;
  }
}

export async function dosacknowledge(data) 
{
  try {
    const options = 
    {
        params: 
        { 
            
            batch_no:data.batch_no,
            received_by:data.received_by,
            issue_Vaccine_quantity:data.issue_Vaccine_quantity,
            
          
        }
    }
    const res=await axios.get(`${API_URL}acknowledgeOrderbyDistrict`, options);
    return await res;
  } catch (e) {
    throw e;
  }
}



export async function distvaccdis(data) {
  try 
  {
    const result= await axios.put(`${API_URL}DistConsignment`,data);
    return await result
  } catch (e) {
    throw e;
  }
}


export async function voacknowledge(data) 
{
  try {
    const options = 
    {
        params: 
        { 
            order_id: data.order_id,
            batch_no:data.batch_no,
            received_by:data.received_by,
            consignment_no:data.consignment_no,
            issue_vaccine_quantity:data.issue_vaccine_quantity,
          
        }
    }
    const res=await axios.get(`${API_URL}vo_ack_receipt`, options);
    return await res;
  } catch (e) {
    throw e;
  }
}

export async function vaccinerecords(data) 
{
  try {
    const options = 
    {
        params: 
        { 
            order_id: data.order_id,
            batch_no: data.batch_no,
            consignment_no:data.consignment_no,
            total_quantity:data.total_quantity,
            consumed:data.consumed,
            damaged:data.damaged,
            remaining:data.remaining
          
        }
    }
    const res=await axios.get(`${API_URL}vaccine_records`, options);
    return await res;
  } catch (e) {
    throw e;
  }
}

export async function distribute_district(data) {
  try 
  {
    const result= await axios.put(`${API_URL}DistributeOrder`,data);
    return await result
  } catch (e) {
    throw e;
  }
}
export async function viewBothOrderStatus(data) {
  try {
    const options = 
    {
        params: 
        { 
            order_id: data.order_id  
           
        }
    }
    
    console.log(options)
    const result= await axios.get(`${API_URL}viewbothStatus`,options);

    return await result
  } catch (e) {
    throw e;
  }
}