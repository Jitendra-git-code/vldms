import axios from 'axios'

const Users_RestApi_URl ="http://localhost:8080/api/v1/view";

class UserService{

    viewAll(){
        return axios.get(Users_RestApi_URl)
    }

    

    viewBothOrderStatusbyStatus(order_id){
        return axios.get(Users_RestApi_URl,order_id)
    }
   
   
    vieworder(add){
        return axios.put(Users_RestApi_URl,add)
    }

    getUser(user_id)
    {
        return axios.get(Users_RestApi_URl,user_id)
    }
}

export default new UserService()