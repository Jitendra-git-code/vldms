import axios from 'axios'

const Users_RestApi_URl ="http://localhost:8080/api/v1/pendingStatus";

class viewpendingService{


 

    viewBothOrderStatusbyStatus(){
        return axios.get(Users_RestApi_URl)
    }
   

}

export default new viewpendingService()