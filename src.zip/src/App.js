import logo from './logo.svg';
import './App.css';
import FirstComponent from './Components/FirstComponent';
import LoginForm from './Components/LoginForm';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import VaccineOfficer from './Components/VaccineOfficer';
import MohOfficer from './Components/MohOfficer';
import ProductionOfficer from './Components/ProductionOfficer';
import DistrictStoreOfficer from './Components/DistrictStoreOfficer';
import StateStoreOfficer from './Components/StateStoreOfficer';
import Register from './Components/Register';
import ViewOrder from './Components/ViewOrder';
import ManageOrder from './Components/ManageOrder';
import CreateOrder from './Components/CreateOrder';
import VOAcknowledgementReceipt from './Components/VOAcknowledgementReceipt';
import VO_VaccineRecords from './Components/VO_VaccineRecords';
import ViewAllForMoH from './Components/ViewAllForMoH';
import UpdateMoH from './Components/UpdateMoH';
import CancelOrderMoH from './Components/CancelOrderMoH';
import DOAcknowledgementReceipt from './Components/DOAcknowledgementReceipt';
import DistrictVaccAllocation from './Components/DistrictVaccAllocation';
import Thankyou from './Components/Thankyou';
import ApproveOrderProduction from './Components/ApproveOrderProduction';
import RejectOrderProduction from './Components/RejectOrderProduction';
import DispatchOrderProduction from './Components/DispatchOrderProduction';
import SOAcknowledgementReceipt from './Components/SOAcknowledgementReceipt';
import SoDistrinbuteVacc from './Components/SoDistributeVacc';
import RequestsOfOrderslist from './Components/RequestsOfOrderslist';
import StatusforBothMohandProduction from './Components/StatusforBothMohandProduction';
function App() {
  return (
    <div className="App" >
     
      
      <Router>
              
                <div >
                  
                    <Switch> 
                          <Route path = "/" exact component = {LoginForm}></Route>
                          <Route path = "/register" component = {Register}></Route>
                          <Route path = "/Moh_officer" component = {MohOfficer}></Route>
                          <Route path = "/production_officer" component = {ProductionOfficer}></Route>
                          <Route path = "/state_officer" component = {StateStoreOfficer}></Route>
                          <Route path = "/district_officer" component = {DistrictStoreOfficer}></Route>
                          <Route path = "/view_order" component = {ViewOrder}></Route>
                          <Route path = "/manage_order" component = {ManageOrder}></Route>
                          <Route path = "/create_order" component = {CreateOrder}></Route>
                          <Route path = "/vacc_officer" component = {VaccineOfficer}></Route>
                          <Route path = "/vo_ack_receipt" component = {VOAcknowledgementReceipt}></Route>
                          <Route path = "/vo_vaccine_records" component = {VO_VaccineRecords}></Route>
                          <Route path = "/viewallStatus" component = {ViewAllForMoH}></Route>
                          <Route path = "/cancel_order" component = {CancelOrderMoH}></Route>
                          <Route path = "/update_order" component = {UpdateMoH}></Route>
                          <Route path = "/dso_ack_receipt" component = {DOAcknowledgementReceipt}></Route>
                          <Route path = "/dso_vaccine_allocation" component = {DistrictVaccAllocation}></Route>
                          <Route path = "/thank_you" component={Thankyou}></Route> 
                          <Route path = "/approve_order" component={ApproveOrderProduction}></Route>
                          <Route path = "/reject_order" component={RejectOrderProduction}></Route>
                          <Route path = "/dispatch_order" component={DispatchOrderProduction}></Route>
                          
                          <Route path = "/status" component={StatusforBothMohandProduction}></Route>
                          <Route path = "/listofrequests" component={RequestsOfOrderslist}></Route>
                          <Route path = "/distributevacc" component={SoDistrinbuteVacc}></Route>
                          <Route path = "/acknowledgeStateUser" component={SOAcknowledgementReceipt}></Route>
                           {/*<Route path = "/add-employee/:id" component = {CreateEmployeeComponent}></Route>*/}
                          {/*<Route path = "/view-employee/:id" component = {ViewEmployeeComponent}></Route>*/}
                          {/* <Route path = "/update-employee/:id" component = {UpdateEmployeeComponent}></Route> */}
                    </Switch>
                </div>
            
        </Router>
    </div>
  );
}

export default App;


