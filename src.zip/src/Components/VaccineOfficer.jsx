import React, { Component } from 'react';
import { Link } from 'react-router-dom';
class VaccineOfficer extends React.Component {
    constructor(props) {
        super(props);
        this.state =
        {
            order_id: "",
            batchno: "",
            consignment_no: "",
            issue_vaccine_quantity: "",
            dispatch_or_receivedate: ""
            
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);
    }
    handleChange(event) {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const order_id = target.order_id;
        const batchno = target.batchno;
        const consignment_no= target.consignment_no;
        const issue_vaccine_quantity=target.issue_vaccine_quantity;
        const dispatch_or_receivedate= target. dispatch_or_receivedate;
       

        this.setState({
            [name]: value,
            [order_id]:value,
            [batchno]:value,
            [consignment_no]:value,
            [issue_vaccine_quantity]:value,
            [dispatch_or_receivedate]:value
            

        });
    }
    handleSubmit(event) {
        event.preventDefault(event);
        console.log(this.state);
        //registeringUser(this.state);
        // checkuser(this.state);
    }
    clearForm() {
        this.setState({
            order_id: "",
            batchno: "",
            consignment_no: "",
            issue_vaccine_quantity: "",
            dispatch_or_receivedate: ""
        });
    }
    render() {
        return (
            <div>
                 <Link to={'/'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                        Logout
                    </button>
                </Link>
                <div className="container mt-5 ">  
               
                
                <h2>Vaccination Officer </h2>
                    <div className="row">
                        <div className="col">
                            <div className="card mx-auto">
                                <div className="card-body">
                                    <div className="form-group">
                                        <div>
                                            <Link to={'/vo_ack_receipt'}>
                                                <button type="button" className="btn btn-primary mt-5 btn-lg btn-block"   >
                                                Acknowledgement Receipt
                                                </button>
                                            </Link>
                                        </div>

                                        <div>
                                            <Link to={'/vo_vaccine_records'}>
                                                <button type="button" className="btn btn-primary mt-5 btn-lg btn-block"   >
                                                Vaccine Records
                                                </button>
                                            </Link>
                                        </div>

                                        <div>
                                            <Link to={'/vo_notification'}>
                                                <button type="button" className="btn btn-primary mt-5 btn-lg btn-block"   >
                                                Notification
                                                </button>
                                             </Link>
                                        </div>
                                    
                                    </div>
                                </div>
                                    
                            </div>
                        </div>
                    </div>
                </div>
            
            </div>
           


        );
    }
}

export default VaccineOfficer;