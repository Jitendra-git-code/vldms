import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { vaccinerecords } from '../API/index';
class VO_VaccineRecords extends Component {
    constructor(props) {
        super(props);
        this.state =
        {
            order_id: "",
            batch_no: "",
            consignment_no: "",
            total_quantity: "",
            consumed: "",
            damaged:"",
            remaining:""
            
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);
    }
    handleChange(event) {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const order_id = target.order_id;
        const batch_no = target.batch_no;
        const consignment_no= target.consignment_no;
        const total_quantity=target.total_quantity;
        const consumed=target.consumed;
       const damaged=target.damaged;
       const remaining=target.remaining;

        this.setState({
            [name]: value,
            [order_id]:value,
            [batch_no]:value,
            [consignment_no]:value,
            [total_quantity]:value,
            [consumed]: value,
            [damaged]:value,
            [remaining]:value
            

        });
    }
    handleSubmit(event) {
        event.preventDefault(event);
        console.log(this.state);
        vaccinerecords(this.state).then(res => {
            this.props.history.push('/thank_you') });
        //registeringUser(this.state);
        // checkuser(this.state);
    }
    clearForm() {
        this.setState({
            order_id: "",
            batch_no: "",
            consignment_no: "",
            total_quantity: "",
            consumed: "",
            damaged:"",
            remaining:""
        });
    }
    render() {
        return (
            <div>
                 <Link to={'/'}>
                    <button type="button" className="btn btn-primary mt-5  " >
                     Logout
                    </button>
                </Link>

                <form
                className="needs-validation"
                noValidate
                onSubmit={this.handleSubmit.bind(this)}
            ><br/>
               <h2>Vaccine Record</h2>
               <br/>
                <div className="container mt-5 ">
                
                
                    <div className="row">
                        <div className="col">
                            <div className="card mx-auto">
                                <div className="card-body">
                              

                                    <div className="form-group">
                                        
                                        <label htmlFor="exampleInputEmail1">Order Number</label>
                                        <input
                                            type="text"
                                            name="order_id"
                                            className="form-control"
                                            id="exampleInputEmail1"
                                            aria-describedby="emailHelp"
                                            required
                                            placeholder="Order No"
                                            value={this.state.order_id}
                                            onChange={this.handleChange}
                                        />
                                        
                                    </div>
                                    
                                    <div className="form-group">
                                        <label htmlFor="exampleInputPassword1">Batch Number</label>
                                        <input
                                            type="text"
                                            name="batch_no"
                                            className="form-control"
                                            id="exampleInputPassword1"
                                            required
                                            placeholder="Batch No"
                                            value={this.state.batch_no}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Consignment Number</label>
                                        <input
                                            type="text"
                                            name="consignment_no"
                                            className="form-control"
                                            required
                                            placeholder="Consignment No"
                                            value={this.state.consignment_no}
                                            onChange={this.handleChange}
                                        />
                                        
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Quantity Of Dosage Received</label>
                                        <input
                                            type="text"
                                            name="total_quantity"
                                            className="form-control"
                                            required
                                            placeholder=" Vaccine_Quantity"
                                            value={this.state. total_quantity}
                                            onChange={this.handleChange}
                                        />
                                        
                                    </div>
                                    {/* <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Vaccination Date</label>
                                        <input
                                            type="date"
                                            name="date"
                                            className="form-control"
                                            required
                                            placeholder="date"
                                            value={this.state.date}
                                            onChange={this.handleChange}
                                        />
                                  
                                    </div > */}
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Vaccines Consumed</label>
                                        <input
                                            type="text"
                                            name="consumed"
                                            className="form-control"
                                            required
                                            placeholder=" Vaccines_Consumed"
                                            value={this.state.consumed}
                                            onChange={this.handleChange}
                                        />
                                        
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1"> Vaccines Damaged</label>
                                        <input
                                            type="text"
                                            name="damaged"
                                            className="form-control"
                                            required
                                            placeholder=" Damaged_Vaccine"
                                            value={this.state.damaged}
                                            onChange={this.handleChange}
                                        />
                                        
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Vaccines Left</label>
                                        <input
                                            type="text"
                                            name="remaining"
                                            className="form-control"
                                            required
                                            placeholder=" Remaining_Vaccines"
                                            value={this.state.remaining}
                                            onChange={this.handleChange}
                                        />
                                        
                                    </div>
            
                                    <button type="submit" className="btn btn-primary" >
                                        Submit
                                    </button>
                                    <button
                                        type="button"
                                        className="btn btn-secondary float-right"
                                        onClick={this.clearForm}
                                    >
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            </div>
            
        );
    }
}

export default VO_VaccineRecords;