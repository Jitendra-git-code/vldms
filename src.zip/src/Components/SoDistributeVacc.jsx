import React from "react";
import { distribute_district } from '../API/index';

import districtnames from '../Constants/districtnames.json';

class SoDistrinbuteVacc extends React.Component {
    constructor(props) {
        super(props);
        this.state =
        {

            order_id: "",
            batch_no: "",
            district_name: "",
            distribution_Date: "",
            issue_Vaccine_quantity: "",
         
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);
    }
    handleChange(event) {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const order_id = target.order_id;
        const batch_no = target.batch_no;
        const district_name = target.district_name;
        const distribution_Date = target.distribution_Date;
        const issue_Vaccine_quantity = target.issue_Vaccine_quantity;
       
        console.log(target);

        this.setState({
            [name]: value,
            [order_id]: value,
            [batch_no]: value,
            [district_name]: value,
            [distribution_Date]: value,
            [issue_Vaccine_quantity]: value,
           
        });
    }
    handleSubmit(event) {
        event.preventDefault(event);
        console.log(this.state);
        distribute_district(this.state);

        // checkuser(this.state);
    }

    clearForm() {
        this.setState({
            order_id: "",
            batch_no: "",
            district_name: "",
            distribution_Date: "",
            issue_Vaccine_quantity: "",
          

        });
    }
    render() {
        return (

            <form
                className="needs-validation"
                noValidate
                onSubmit={this.handleSubmit}
            >
                <h1> Create Order Page</h1>
                <div className="container mt-5 ">
                    <div className="row">
                        <div className="col">
                            <div className="card mx-auto">
                                <div className="card-body">
                                <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Order Id</label>
                                        <input
                                            type="text"
                                            name="order_id"
                                            className="form-control"
                                            required
                                            placeholder="Order ID"
                                            value={this.state.order_id}
                                            onChange={this.handleChange}
                                        />
                                    </div>

                                                                    

                                  

                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Number of vaccine to be issued</label>
                                        <input
                                            type="text"
                                            name="issue_Vaccine_quantity"
                                            className="form-control"
                                            required
                                            placeholder="Quantity of vaccine"
                                            value={this.state.issue_Vaccine_quantity}
                                            onChange={this.handleChange}
                                        />
                                   
                                        <div >
                                        <br />
                                        </div >  
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">District Name</label>
                                        
                                      <select onChange={this.handleChange} name="district_name" value={this.state.district_name}>
                                            {districtnames.map(abc => {
                                                return (
                                                    <option value={abc.value}>
                                                        {abc.name}

                                                    </option>

                                                );
                                            })}
                                        </select>

                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Date of Distribution</label>
                                        <input
                                            type="date"
                                            name="distribution_Date"
                                            className="form-control"
                                            required
                                            placeholder="distribution_Date Date"
                                            value={this.state.distribution_Date}
                                            onChange={this.handleChange}
                                        /> 
                                       
                                   
                                    </div >                       
                                                

                                        <br />

                                    </div>
                                    <button type="submit" className="btn btn-primary" >
                                        Submit
                                    </button>
                                    <button
                                        type="button"
                                        className="btn btn-secondary float-right"
                                        onClick={this.clearForm}
                                    >
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        );
    }
}
export default SoDistrinbuteVacc;
