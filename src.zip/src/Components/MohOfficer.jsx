import axios from 'axios';
import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import UserService from '../services/userService'

class MohOfficer extends Component {
    constructor(props) 
  {
      super(props);
      this.state ={
       users: []
      }
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    
    console.log(this.props);
    const { history } = this.props;
  }
  handleChange(event) {
    const target = event.target;
    const value = target.value;
   

      

  }
  handleSubmit(event) {
    event.preventDefault(event);
    console.log(this.state);
  
    
  }
  componentDidMount(){
    // UserService.getUser().then((res) => {
    //     this.setState({users: res.data});
    //     console.log(res)
    // });
    console.log(this.state.users)
}
  



    render() {
        return (
            <div>
                <h1>MoHFW officer's Home Page</h1>
                <Link to={'/view_order'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     View Order
                    </button>
                </Link>
                <span>  </span>
                <Link to={'/manage_order'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Manage Order
                    </button>
                </Link>
                <span>  </span>
                <Link to={'/'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Logout
                    </button>
                </Link>

                {/* {
                                   
                                   this.state.users.map((user,index)=>{
                                              return(
                                                  <tr key={user.order_id}>
                                                       <td> {user.name}</td>

                                                  </tr>
                                                )
                                              })
                                          } */}
            </div>
        );
    }
}

export default MohOfficer;