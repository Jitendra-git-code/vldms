import React from "react";
import { CreatingOrder } from '../API/index';
import { Dropdown } from 'react-router-dom'
import typeofvaccine from '../Constants/typeofvaccine.json';
import companyname from '../Constants/companyname.json';
import RegionalOffice from '../Constants/RegionalOffice.json';
import Statenames from '../Constants/Statenames.json';
import mfgcompanyLOC from '../Constants/mfgcompanyLOC.json';
class CreateOrder extends React.Component {
    constructor(props) {
        super(props);
        this.state =
        {

            order_id: "",
            ordered_by: "",
            date_of_order: new Date(),
            type_of_vaccine: "",
            Company_Name: "",
            Destination_State: "",
            State_regional_office: "",
            Quantity_of_vaccine: "",
            Manufacturer_Location: "",
            upadted_Quantity: ""
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);
    }
    handleChange(event) {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const order_id = target.order_id;
        const ordered_by = target.ordered_by;
        const date_of_order = target.date_of_order;
        const type_of_vaccine = target.type_of_vaccine;
        const Company_Name = target.Company_Name;
        const Destination_State = target.Destination_State;
        const State_regional_office = target.State_regional_office;
        const Quantity_of_vaccine = target.Quantity_of_vaccine;
        const Manufacturer_Location = target.Manufacturer_Location;
        const upadted_Quantity = target.upadted_Quantity;
        console.log(target);

        this.setState({
            [name]: value,
            [order_id]: value,
            [ordered_by]: value,
            [date_of_order]: value,
            [type_of_vaccine]: value,
            [Company_Name]: value,
            [Destination_State]: value,
            [State_regional_office]: value,
            [Quantity_of_vaccine]: value,
            [Manufacturer_Location]: value,
            [upadted_Quantity]: value
        });
    }
    handleSubmit(event) {
        event.preventDefault(event);
        console.log(this.state);
        CreatingOrder(this.state);

        // checkuser(this.state);
    }

    clearForm() {
        this.setState({
            order_id: "",
            ordered_by: "",
            date_of_order: "",
            type_of_vaccine: "",
            company_Name: "",
            destination_State: "",
            quantity_of_vaccine: "",
            state_regional_office: "",
            manufacturer_Location: "",
            upadted_Quantity: ""

        });
    }
    render() {
        return (

            <form
                className="needs-validation"
                noValidate
                onSubmit={this.handleSubmit}
            >
                <h1> Create Order Page</h1>
                <div className="container mt-5 ">
                    <div className="row">
                        <div className="col">
                            <div className="card mx-auto">
                                <div className="card-body">


                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Ordered by</label>
                                        <input
                                            type="text"
                                            name="ordered_by"
                                            className="form-control"
                                            required
                                            placeholder="Order by"
                                            value={this.state.ordered_by}
                                            onChange={this.handleChange}
                                        />
                                    </div>

                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Type of Vaccine</label>
                                        {/* <input
                                            type="text"
                                            name="type_of_vaccine"
                                            className="form-control"
                                            required
                                            placeholder="type of vaccine"
                                            value={this.state.type_of_vaccine}
                                            onChange={this.handleChange}
                                        /> */}
                                        <select onChange={this.handleChange} name="type_of_vaccine" value={this.state.type_of_vaccine}>
                                            {typeofvaccine.map(abc => {
                                                return (
                                                    <option value={abc.value}>
                                                        {abc.name}

                                                    </option>

                                                );
                                            })}
                                        </select>

                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Company Name</label>
                                        {/* <input
                                            type="text"
                                            name="company_Name"
                                            className="form-control"
                                            required
                                            placeholder=" company_Name"
                                            value={this.state.company_Name}
                                            onChange={this.handleChange}
                                        /> */}
                                        <select onChange={this.handleChange} name="company_Name" value={this.state.company_Name}>
                                            {companyname.map(abc => {
                                                return (
                                                    <option value={abc.value}>
                                                        {abc.name}

                                                    </option>

                                                );
                                            })}
                                        </select>
                                    </div>

                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Quantity of vaccine</label>
                                        <input
                                            type="text"
                                            name="quantity_of_vaccine"
                                            className="form-control"
                                            required
                                            placeholder="Quantity of vaccine"
                                            value={this.state.quantity_of_vaccine}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Destination State</label>
                                        {/* <input
                                            type="text"
                                            name="destination_State"
                                            className="form-control"
                                            required
                                            placeholder="Destination State"
                                            value={this.state.destination_State}
                                            onChange={this.handleChange}
                                        /> */}
                                        <select onChange={this.handleChange} name="destination_State" value={this.state.destination_State}>
                                            {Statenames.map(abc => {
                                                return (
                                                    <option value={abc.value}>
                                                        {abc.name}

                                                    </option>

                                                );
                                            })}
                                        </select>

                                        
                                        <div >
                                        <br />
                                        </div >  
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">State_regional_office</label>
                                        {/* <input
                                            type="text"
                                            name="state_regional_office"
                                            className="form-control"
                                            required
                                            placeholder=" state regional office"
                                            value={this.state.state_regional_office}
                                            onChange={this.handleChange}
                                        /> */}
                                        <select onChange={this.handleChange} name="state_regional_office" value={this.state.state_regional_office}>
                                            {RegionalOffice.map(abc => {
                                                return (
                                                    <option value={abc.value}>
                                                        {abc.name}

                                                    </option>

                                                );
                                            })}
                                        </select>

                                    </div>
                                        <div className="form-group">
                                            <label htmlFor="exampleInputEmail1">Manufacturer_Location</label>
                                            {/* <input
                                            type="text"
                                            name="manufacturer_Location"
                                            className="form-control"
                                            required
                                            placeholder="Manufacturer Location"
                                            value={this.state.manufacturer_Location}
                                            onChange={this.handleChange}
                                        /> */}
                                            <select onChange={this.handleChange} name="manufacturer_Location" value={this.state.manufacturer_Location}>
                                                {mfgcompanyLOC.map(abc => {
                                                    return (
                                                        <option value={abc.value}>
                                                            {abc.name}

                                                        </option>

                                                    );
                                                })}
                                            </select>
                                        </div>

                                    


                                        <br />
                                    </div>
                                    <button type="submit" className="btn btn-primary" >
                                        Submit
                                    </button>
                                    <button
                                        type="button"
                                        className="btn btn-secondary float-right"
                                        onClick={this.clearForm}
                                    >
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        );
    }
}
export default CreateOrder;
