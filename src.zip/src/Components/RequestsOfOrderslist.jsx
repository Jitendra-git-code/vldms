import axios from "axios";
import React, { Component, useState } from 'react';
import { Button, NavLink, Table } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import viewpendingService from '../services/viewpendingService'


class ViewAllForMoH extends React.Component {

    constructor(props) {
        super(props)

        this.state =
        {
            users: []
        };
       
    }
     
    
    componentDidMount() {
        viewpendingService.viewBothOrderStatusbyStatus().then((res) => {
            this.setState({ users: res.data });
            console.log(res)
        });
        console.log(this.state.users)
    }
    render() {
        return (
            <div>
                <h1>View All Order</h1>
                <Link to={'/'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                        Logout
                    </button>
                </Link>
                <Table striped bordered hover>
                    <thead>
                        <tr>

                            <th>order_id</th>
                            <th>ordered_by</th>
                            <th>date_of_order</th>
                            <th>type_of_vaccine</th>
                            <th>Company_Name</th>
                            <th>Destination_State</th>
                            <th>State_regional_office</th>
                            <th>Quantity_of_vaccine</th>
                            <th>Manufacturer Location</th>
                            <th>upadted_Quantity</th>
                            <th> Order Status of Approval</th>
                            <th> Comment text</th>
                            <th> Date of Update Status</th>
                            <th> Action performed by</th>
                        </tr>
                    </thead>
                    <tbody>

                        {

                            this.state.users.map((user, index) => {
                                return (
                                    <tr key={user.order_id}>
                                        <td> {user.order_id}</td>
                                        <td>{user.ordered_by}</td>
                                        <td>{user.date_of_order}</td>
                                        <td>{user.type_of_vaccine}</td>
                                        <td>{user.company_Name}</td>
                                        <td>{user.destination_State}</td>
                                        <td>{user.state_regional_office}</td>
                                        <td>{user.quantity_of_vaccine}</td>
                                        <td>{user.manufacturer_Location}</td>
                                        <td>{user.upadted_Quantity.toString()}</td>
                                        <td>{user.order_Status_of_Approval}</td>
                                        <td>{user.comment_text}</td>
                                        <td>{user.date_of_Update_Status}</td>
                                        <td>{user.action_performed_by}</td>

                                    </tr>
                                )
                            })
                        }



                    </tbody>

                </Table>
            </div>
        );
    }

}
export default ViewAllForMoH;
