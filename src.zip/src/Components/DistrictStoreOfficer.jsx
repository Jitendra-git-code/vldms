import React, { Component } from 'react';
import { Link } from 'react-router-dom';
class DistrictStoreOfficer extends React.Component {
    constructor(props) {
        super(props);
        this.state =
        {
            batch_no: "",
            received_by: "",
            issue_Vaccine_quantity: ""
           
            
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);
    }
    handleChange(event) {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const batch_no = target.batch_no;
        const received_by= target.received_by;
        const issue_vaccine_quantity=target.issue_vaccine_quantity;
       

        this.setState({
            [name]: value,
           
            [batch_no]:value,
            [received_by]:value,
            [issue_vaccine_quantity]:value,
           
            

        });
    }
    handleSubmit(event) {
        event.preventDefault(event);
        console.log(this.state);
        //registeringUser(this.state);
        // checkuser(this.state);
    }
    clearForm() {
        this.setState({
            batch_no: "",
            received_by: "",
            issue_Vaccine_quantity: ""
        });
    }
    render() {
        return (
            <div>
                <Link to={'/'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                        Logout
                    </button>
                </Link>
                <div className="container mt-5 ">  
                    <h2>District Store Officer </h2>
                    <div className="row">
                        <div className="col">
                            <div className="card mx-auto">
                                <div className="card-body">
                                    <div className="form-group">
                                        <div>
                                            <Link to={'/dso_ack_receipt'}>
                                                <button type="button" className="btn btn-primary mt-5 btn-lg btn-block"   >
                                                Acknowledgement Receipt
                                                </button>
                                            </Link>
                                        </div>

                                        <div>
                                            <Link to={'/dso_vaccine_allocation'}>
                                                <button type="button" className="btn btn-primary mt-5 btn-lg btn-block"   >
                                                Allocation of vaccine to Vaccination Centre
                                                </button>
                                            </Link>
                                        </div>

                                       
                                    
                                    </div>
                                </div>
                                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default DistrictStoreOfficer;