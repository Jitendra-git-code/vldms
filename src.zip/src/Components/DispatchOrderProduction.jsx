import axios from 'axios';
import React,{Component} from 'react'
import { dispatchOrder } from '../API/index';
class DispatchOrderProduction extends React.Component
{
    constructor(props) {
        super(props);
        this.state =
        {   
            order_id : "",
            manufacture_date_of_vaccine :"",
            dispatched_by : ""
        }; 
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);
    } 
        handleChange(event) {
                    const target = event.target;
                    const value = target.value;
                    const name = target.name;
                    const order_id =target.order_id;
                    const manufacture_date_of_vaccine= target.manufacture_date_of_vaccine;
                    const dispatched_by = target.dispatched_by;

        this.setState({
            [name]: value,
            [order_id]: value,
            [manufacture_date_of_vaccine]: value,
            [dispatched_by]: value
        }); 
}
handleSubmit(event){
    event.preventDefault(event);
    console.log(this.state);
    dispatchOrder(this.state);
    
};
clearForm() {
    this.setState({
        order_id: "",
        manufacture_date_of_vaccine:"",      
        dispatched_by:""

    });
}
render()
{


return(
<form
                className="needs-validation"
                noValidate
                onSubmit={this.handleSubmit}
            >
                <h1>Dispatch Order Page for production officer</h1>
                <div className="container mt-5 ">
                    <div className="row">
                        <div className="col">
                            <div className="card mx-auto">
                                <div className="card-body">
                                   
                                   
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Order Id</label>
                                        <input
                                            type="text"
                                            name="order_id"
                                            className="form-control"
                                            required
                                            placeholder="Order NO"
                                            value={this.state.order_id}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Manufacturing date of vaccine</label>
                                        <input
                                            type="date"
                                            name="manufacture_date_of_vaccine"
                                            className="form-control"
                                            required
                                            placeholder="manufacture_date_of_vaccine "
                                            value={this.state.manufacture_date_of_vaccine}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Dispatched by</label>
                                        <input
                                            type="text"
                                            name="dispatched_by"
                                            className="form-control"
                                            required
                                            placeholder="Dispatched by "
                                            value={this.state.dispatched_by}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                
                                    
                                   
                                    <button type="submit" className="btn btn-primary" >
                                        Submit
                                    </button>
                                    <span>  </span>
                                    <button
                                        type="button"
                                        className="btn btn-secondary float-right"
                                        onClick={this.clearForm}
                                    >
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>


)    


}


    }

export default DispatchOrderProduction;