import React, { Component } from 'react';
import { Link } from 'react-router-dom';
class StateStoreOfficer extends Component {
    render() {
        return (
            <div>
                <h1>State Store Officer's Home Page</h1>
                
               
                <Link to={'/acknowledgeStateUser'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Acknowledge Reciept of Order
                    </button>
                </Link>
                <span>  </span>
                <Link to={'/distributevacc'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Distribute Vaccine
                    </button>
                </Link>
                <span>  </span>
                <Link to={'/'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Logout
                    </button>
                </Link>
            </div>
        );
    }
}

export default StateStoreOfficer;