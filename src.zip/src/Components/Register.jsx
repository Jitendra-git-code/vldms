import React from "react";
import { registeringUser } from '../API/index';
import {Dropdown} from 'react-router-dom'
class Register extends React.Component {
    constructor(props) {
        super(props);
        this.state =
        {
            user_id: "",
            password: "",
            name: "",
            type_of_user: "",
            email_id: "",
            mobile_no: ""
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);
    }
    handleChange(event) {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const user_id = target.user_id;
        const password = target.password;
        const type_of_user= target.type_of_user;
        const email_id= target. email_id;
        const mobile_no=target.mobile_no;

        this.setState({
            [name]: value,
            [user_id]:value,
            [password]:value,
            [type_of_user]:value,
            [email_id]:value,
            [mobile_no]:value

        });
    }
    handleSubmit(event) {
        event.preventDefault(event);
        console.log(this.state);
        registeringUser(this.state);
        
        // checkuser(this.state);
    }
    clearForm() {
        this.setState({
            user_id: "",
            name : "",
            password: "",
            type_of_user: "",
            email_id: "",
            mobile_no: ""
        });
    }
    render() {
        return (
            
            <form
                className="needs-validation"
                noValidate
                onSubmit={this.handleSubmit}
            >
                <h1>Register User </h1>
                <div className="container mt-5 ">
                    <div className="row">
                        <div className="col">
                            <div className="card mx-auto">
                                <div className="card-body">
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">User_id</label>
                                        <input
                                            type="text"
                                            name="user_id"
                                            className="form-control"
                                            id="exampleInputEmail1"
                                            aria-describedby="emailHelp"
                                            required
                                            placeholder="Username"
                                            value={this.state.user_id}
                                            onChange={this.handleChange}
                                        />
                                        
                                    </div>
                                    
                                    <div className="form-group">
                                        <label htmlFor="exampleInputPassword1">Password</label>
                                        <input
                                            type="password"
                                            name="password"
                                            className="form-control"
                                            id="exampleInputPassword1"
                                            required
                                            placeholder="Password"
                                            value={this.state.password}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">name</label>
                                        <input
                                            type="text"
                                            name="name"
                                            className="form-control"
                                            required
                                            placeholder="name"
                                            value={this.state.name}
                                            onChange={this.handleChange}
                                        />
                                        
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Type of User</label>
                                        <input
                                            type="text"
                                            name="type_of_user"
                                            className="form-control"
                                            required
                                            placeholder=" type_of_user"
                                            value={this.state.type_of_user}
                                            onChange={this.handleChange}
                                        />
                                    
                                    </div>
                                    
                                 
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">EmailId</label>
                                        <input
                                            type="email"
                                            name="email_id"
                                            className="form-control"
                                            required
                                            placeholder="email_id"
                                            value={this.state.email_id}
                                            onChange={this.handleChange}
                                        />
                                       
                                   
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Mobile No</label>
                                        <input
                                            type="text"
                                            name="mobile_no"
                                            className="form-control"
                                            required
                                            placeholder="mobile_no"
                                            value={this.state.mobile_no}
                                            onChange={this.handleChange}
                                        />
                                       
                                    </div>
                                    <div >
                                    </div >

                                        <div>Selected: {this.state.type_of_user}</div>
                                        <br />
                                    </div>
                                    <button type="submit" className="btn btn-primary" >
                                    Register
                                    </button>
                                    <button
                                        type="button"
                                        className="btn btn-secondary float-right"
                                        onClick={this.clearForm}
                                    >
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        );
    }
}
export default Register;
