import axios from 'axios';
import React,{Component} from 'react'
import { rejectOrder } from '../API/index';
class RejectOrderProduction extends React.Component
{
    constructor(props) {
        super(props);
        this.state =
        {   
            order_id : "",
            action_performed_by : ""
        }; 
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);
    } 
        handleChange(event) {
                    const target = event.target;
                    const value = target.value;
                    const name = target.name;
                    const order_id =target.order_id;
                    const action_performed_by = target.action_performed_by;

        this.setState({
            [name]: value,
            [order_id]: value,
            [action_performed_by]: value

        }); 
}
handleSubmit(event){
    event.preventDefault(event);
    console.log(this.state);
    rejectOrder(this.state);
    
};
clearForm() {
    this.setState({
        order_id: "",
        action_performed_by:"",
        
        

    });
}
render()
{


return(
<form
                className="needs-validation"
                noValidate
                onSubmit={this.handleSubmit}
            >
                <h1>Reject Order Page for production officer</h1>
                <div className="container mt-5 ">
                    <div className="row">
                        <div className="col">
                            <div className="card mx-auto">
                                <div className="card-body">
                                   
                                   
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Order Id</label>
                                        <input
                                            type="text"
                                            name="order_id"
                                            className="form-control"
                                            required
                                            placeholder="Order NO"
                                            value={this.state.order_id}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    
                                
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">action_performed_by</label>
                                        <input
                                            type="text"
                                            name="action_performed_by"
                                            className="form-control"
                                            required
                                            placeholder="action_performed_by"
                                            value={this.state.action_performed_by}
                                            onChange={this.handleChange}
                                        />
                                    
                                    </div>
                                    <button type="submit" className="btn btn-primary" >
                                        Submit
                                    </button>
                                    <button
                                        type="button"
                                        className="btn btn-secondary float-right"
                                        onClick={this.clearForm}
                                    >
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>


)    


}


    }

export default RejectOrderProduction;