import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import{acknowrder} from '../API/index';

class SOAcknowledgementReceipt extends React.Component {
    constructor(props) {
        super(props);
        this.state =
        {
            order_id: "",
            received_by: "",
            quantity_of_vaccine: "",
            manufacture_date_of_vaccine:"",
            company_Name: ""
        };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.clearForm = this.clearForm.bind(this);
}
handleChange(event) {
    const target = event.target;
    const value = target.value;
    const name = target.name;
    const order_id = target.order_id;
    const received_by= target.received_by;
    const quantity_of_vaccine=target.quantity_of_vaccine;
    const manufacture_date_of_vaccine=target.manufacture_date_of_vaccine;
    const company_Name=target.company_Name;

    this.setState({
        [name]: value,
        [order_id]:value,
        [received_by]:value,
        [quantity_of_vaccine]:value,
       [manufacture_date_of_vaccine]:value,
       [company_Name]:value
        

    });
}
handleSubmit(event) {
    event.preventDefault(event);
    console.log(this.state);
    acknowrder(this.state);
    //registeringUser(this.state);
    // checkuser(this.state);
}
clearForm() {
    this.setState({
        batch_no: "",
        received_by: "",
        issue_Vaccine_quantity: ""
    });
}
    render() {

        return (
            <div>
                <Link to={'/'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                        Logout
                    </button>
                </Link>

                <form
                className="needs-validation"
                noValidate
                onSubmit={this.handleSubmit}
            ><br/>
              <h2> Acknowledgement Receipt</h2>
               <br/>
                <div className="container mt-5 ">
                
                
                    <div className="row">
                        <div className="col">
                            <div className="card mx-auto">
                                <div className="card-body">
                              

                                   
                                    
                                <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Order Id</label>
                                        <input
                                            type="text"
                                            name="order_id"
                                            className="form-control"
                                            required
                                            placeholder="Order ID"
                                            value={this.state.order_id}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Received By</label>
                                        <input
                                            type="text"
                                            name="received_by"
                                            className="form-control"
                                            required
                                            placeholder="Received by"
                                            value={this.state.received_by}
                                            onChange={this.handleChange}
                                        />
                                        
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Quantity Of vaccine</label>
                                        <input
                                            type="text"
                                            name="quantity_of_vaccine"
                                            className="form-control"
                                            required
                                            placeholder=" Vaccine_Quantity"
                                            value={this.state.quantity_of_vaccine}
                                            onChange={this.handleChange}
                                        />
                                        
                                    </div>
                                     <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Date of Manufacturing</label>
                                        <input
                                            type="date"
                                            name="manufacture_date_of_vaccine"
                                            className="form-control"
                                            required
                                            placeholder="Manufacturing Date"
                                            value={this.state.manufacture_date_of_vaccine}
                                            onChange={this.handleChange}
                                        /> 
                                       
                                   
                                    </div >

                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Company Name</label>
                                        <input
                                            type="text"
                                            name="company_Name"
                                            className="form-control"
                                            required
                                            placeholder="Company Name"
                                            value={this.state.company_Name}
                                            onChange={this.handleChange}
                                        />
                                        
                                    </div>
                                    <button type="submit" className="btn btn-primary" >
                                        Submit
                                    </button>
                                        <button
                                            type="button"
                                            className="btn btn-secondary float-right"
                                            onClick={this.clearForm}
                                    >
                                            Cancel
                                        </button>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        );
    }
}

export default SOAcknowledgementReceipt;