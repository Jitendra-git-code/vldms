import React from "react";
import {checkuser} from '../API/index';
import { Link } from 'react-router-dom';
class LoginForm extends React.Component 
{
  constructor(props) 
  {
      super(props);
      this.state = 
      {
        user_id: "",
        password: "",
        type_of_user:""
     };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.clearForm = this.clearForm.bind(this);
    console.log(this.props);
    const { history } = this.props;
  }
  handleChange(event) {
    const target = event.target;
    const value = target.value;
    const name = target.name;
    const user_id = target.user_id;
    const password = target.password;
    const type_of_user= target.type_of_user;

    this.setState({
      [name]: value,
      [user_id]:value,
      [password]:value,
      [type_of_user]:value,
    });
  }
  handleSubmit(event) {
    event.preventDefault(event);
    console.log(this.state);
    
      checkuser(this.state).then(res=>{
      console.log(res);
      // (res.data.type_of_user !=null) && this.props.history.push('/MoH_officer');
        if(res.user_id === "")
        {
          this.props.history.push('/')
        }
        else{
        if(res.data.type_of_user === "MoHFW_Officer")
        {
          this.props.history.push('/MoH_officer')
        }
        if(res.data.type_of_user === "Production_Officer")
        {
          this.props.history.push('/production_officer')
        }
        if(res.data.type_of_user === "State_Store_Officer")
        {
          this.props.history.push('/state_officer')
        }
        if(res.data.type_of_user === "District_Store_Officer")
        {
          this.props.history.push('/district_officer')
        }
        if(res.data.type_of_user === "Vaccination_Officer")
        {
          this.props.history.push('/vacc_officer')
        }
      }
    
    
    })
  
  }
  clearForm() {
    this.setState({
      user_id: "",
      password: "",
      type_of_user: ""
    });
  }

  
  render() {
    return (
      <div>
      <h1> Vaccine Logistic Data Management  System</h1>
      <form
        className="needs-validation"
        noValidate
        onSubmit={this.handleSubmit}
      >
         <div className="container mt-5 ">
        <div className="row">
          <div className="col">
            <div className="card mx-auto">
              <div className="card-body">
        <div className="form-group">
          <label htmlFor="exampleInputEmail1">User ID</label>
          <input
            type="text"
            name="user_id"
            className="form-control"
            id="exampleInputEmail1"
            aria-describedby="emailHelp"
            required
            placeholder="User_id"
            value={this.state.user_id}
            onChange={this.handleChange}
          />
          <small id="emailHelp" className="form-text text-muted">
            We'll never share your email with anyone else.
          </small>
        </div>
        <div className="form-group">
          <label htmlFor="exampleInputPassword1">Password</label>
          <input
            type="password"
            name="password"
            className="form-control"
            id="exampleInputPassword1"
            required
            placeholder="Password"
            value={this.state.password}
            onChange={this.handleChange}
          />
          <small id="emailHelp" className="form-text text-muted">
            Your Password is secured here !!
          </small>
        </div>
        <div >
        <div>
          <label>
            <input
              type="radio"
              name="type_of_user"
              value="MoHFW_Officer"
              checked={this.state.type_of_user === "MoHFW_Officer"}
              onChange={this.handleChange}
            />{" "}
            MoHFW Officer
          </label>
        </div>
        <div>
          <label>
            <input
              type="radio"
              name="type_of_user"
              value="Production_Officer "
              checked={this.state.type_of_user === "Production_Officer "}
              onChange={this.handleChange}
            />{" "}
            Production Officer
          </label>
        </div>
        <div>
          <label>
            <input
              type="radio"
              name="type_of_user"
              value="State_Store_Officer"
              checked={this.state.type_of_user === "State_Store_Officer"}
              onChange={this.handleChange}
            />{" "}
            State Store Officer
          </label>
        </div>
        <div>
          <label>
            <input
              type="radio"
              name="type_of_user"
              value="District_Store_Officer"
              checked={this.state.type_of_user === "District_Store_Officer"}
              onChange={this.handleChange}
            />{" "}
            District Store Officer
          </label>
        </div>
        <div>
          <label>
            <input
              type="radio"
              name="type_of_user"
              value="Vaccination_Officer"
              checked={this.state.type_of_user === "Vaccination_Officer"}
              onChange={this.handleChange}
            />{" "}
            Vaccination Officer
          </label>
        </div>
        <div>Selected: {this.state.type_of_user}</div>
        <br/>
      </div>
        <button type="submit" className="btn btn-primary mt-5" > LOGIN </button>
        <span>  </span>
        <Link to="/register">
        <button type="button" className="btn btn-primary mt-5 "> SIGNUP </button>
      </Link>
      
        <button
          type="button"
          className="btn btn-secondary float-right"
          onClick={this.clearForm}
        >
          Cancel
        </button>
      </div>
      </div>
      </div>
      </div>
      </div>
      </form>
      </div>
    );
  }
}
export default LoginForm ;
