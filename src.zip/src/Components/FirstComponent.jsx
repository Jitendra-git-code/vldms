import React,{ Component } from "react"


class FirstComponent extends Component {
    constructor()
    {
        super();
        this.state={
            counter:0
        }
        this.Loginuser=this.Loginuser.bind(this);
    }


    render() {
        return (
            <div className="firstComponent">
            firstComponent
            <br/>
            <button onClick={this.Loginuser}>Login</button>
            <span>{this.state.counter}</span>

            </div>
        );
    }
    Loginuser()
    {
        this.setState({counter: this.state.counter+1});
        console.log('Login Button Clicked!!');
    }

}

export default FirstComponent;
