import React, { Component } from 'react';

class Thankyou extends Component {
    render() {
        return (
            <div className="container mt-5 ">
                {/* <Alert variant="success"> */}
              
                <h1>Thank You For Acknowledging</h1>
                <br/>
                <p>
                         You have successfully submitted the the Acknowledgement Receipt.<br/> 
                         The concern authorities will get back to you shortly.
                 </p>
               
                {/* </Alert> */}
            </div>
        );
    }
}

export default Thankyou;