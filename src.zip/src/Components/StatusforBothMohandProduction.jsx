import axios from 'axios';
import React, { Component } from 'react'
import { Button, NavLink, Table } from 'react-bootstrap';
import { viewBothOrderStatus } from '../API/index';
class StatusforBothMohandProduction extends React.Component {
    constructor(props) {
        super(props);
        this.state =
        {
            order_id: "",
            users: []
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);
    }
    handleChange(event) {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const order_id = target.order_id;


        this.setState({
            [name]: value,
            [order_id]: value,


        });
    }
    handleSubmit(event) {
        event.preventDefault(event);
        console.log(this.state);
        viewBothOrderStatus(this.state).then(res => {
            this.setState({ users: res.data });

        });

        // checkuser(this.state);
    };
    clearForm() {
        this.setState({
            order_id: ""



        });
    }


    render() {


        return (
            <form
                className="needs-validation"
                noValidate
                onSubmit={this.handleSubmit}
            >

                <h1>View Order Status </h1>
                <div className="container mt-5 ">
                    <div className="row">
                        <div className="col">
                            <div className="card mx-auto">
                                <div className="card-body">


                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Order Id</label>
                                        <input
                                            type="text"
                                            name="order_id"
                                            className="form-control"
                                            required
                                            placeholder="Enter the Order ID here"
                                            value={this.state.order_id}
                                            onChange={this.handleChange}
                                        />
                                    </div>


                                    <button type="submit" className="btn btn-primary" >
                                        Submit
                                    </button>
                                    <button
                                        type="button"
                                        className="btn btn-secondary float-right"
                                        onClick={this.clearForm}
                                    >
                                        Cancel
                                    </button>





                                </div>


                            </div>
                        </div>
                    </div>
                </div>
                <br/>
                <Table striped bordered hover size="sm" >
                    <thead>
                        <tr>

                            <th>Order ID</th>
                            <th>Ordered by</th>
                            <th>Date of order</th>
                            <th>Type of vaccine</th>
                            <th>Company Name</th>
                            <th>Destination State</th>
                            <th>State Regional office</th>
                            <th>Qu. of Vaccine</th>
                            <th>Manufacturer Location</th>
                            <th>Upadted</th>
                            <th>Order Status of Approval</th>
                            <th> Comment text</th>
                            <th> Date of Update Status</th>
                            <th> Action performed by</th>
                        </tr>
                    </thead>
                    <tbody>

                        {

                            this.state.users.map((user, index) => {
                                return (
                                    <tr key={user.order_id}>
                                        <td> {user.order_id}</td>
                                        <td>{user.ordered_by}</td>
                                        <td>{user.date_of_order}</td>
                                        <td>{user.type_of_vaccine}</td>
                                        <td>{user.company_Name}</td>
                                        <td>{user.destination_State}</td>
                                        <td>{user.state_regional_office}</td>
                                        <td>{user.quantity_of_vaccine}</td>
                                        <td>{user.manufacturer_Location}</td>
                                        <td>{user.upadted_Quantity.toString()}</td>
                                        <td>{user.order_Status_of_Approval}</td>
                                        <td>{user.comment_text}</td>
                                        <td>{user.date_of_Update_Status}</td>
                                        <td>{user.action_performed_by}</td>

                                    </tr>
                                )
                            })
                        }



                    </tbody>

                </Table>
            </form>


        )


    }


}

export default StatusforBothMohandProduction;