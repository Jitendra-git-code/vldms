import React, { Component } from 'react';
import { Link } from 'react-router-dom';
class ProductionOfficer extends Component {
    render() {
        return (
            <div>
                <h1>Production Officer's Home Page</h1>
                <Link to={'/approve_order'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Aprrove Order
                    </button>
                </Link>
                <br></br>
                <span>  </span>
                <Link to={'/reject_order'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Reject Order
                    </button>
                </Link>
                <br></br>
                <span>  </span>
                <Link to={'/dispatch_order'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Dispatch Order
                    </button>
                </Link>
                <br></br>
                <span>  </span>
                <Link to={'/listofrequests'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Order Requested by MoHFW officer
                    </button>
                </Link>
                <br></br>
                <span>  </span>
                <Link to={'/'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Logout
                    </button>
                </Link>
            </div>
        );
    }
}

export default ProductionOfficer;