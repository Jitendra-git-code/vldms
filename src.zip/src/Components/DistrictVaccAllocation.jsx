import React, { Component } from 'react';
import {distvaccdis} from '../API/index';
import vacclocation from '../Constants/vacclocation.json';
class DistrictVaccAllocation extends React.Component {
    constructor(props) {
        super(props);
        this.state =
        {
            vacc_office_location: "",
            order_id: "",
            batch_no: "",
            issue_vaccine_quantity: ""
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);
    }
    handleChange(event) {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        const vacc_office_location = target.vacc_office_location;
        const order_id = target.order_id;
        const batch_no= target.batch_no;
        const issue_vaccine_quantity=target.issue_vaccine_quantity;
        console.log(target);

        this.setState({
            [name]: value,
            [vacc_office_location]:value,
            [order_id]:value,
            [batch_no]:value,
            [issue_vaccine_quantity]:value

        });
    }
    handleSubmit(event) {
        event.preventDefault(event);
        console.log(this.state);
        distvaccdis(this.state).then(res => {
            this.props.history.push('/thank_you') });
        //registeringUser(this.state);
        // checkuser(this.state);
    }
    clearForm() {
        this.setState({
            vacc_office_location: "",
            order_id: "",
            batch_no: "",
            issue_vaccine_quantity: ""
        });
    }
    render() {
        return (
            <form
                className="needs-validation"
                noValidate
                onSubmit={this.handleSubmit.bind(this)}
            >
                <div className="container mt-5 ">
                    <div className="row">
                        <div className="col">
                            <div className="card mx-auto">
                                <div className="card-body">
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Centre Name</label>
                                        {/* <input
                                            type="text"
                                            name="vacc_office_location"
                                            className="form-control"
                                            id="exampleInputEmail1"
                                            aria-describedby="emailHelp"
                                            required
                                            placeholder="Centre Name"
                                            value={this.state.vacc_office_location}
                                            onChange={this.handleChange}
                                        /> */}
                                        <select  onChange={this.handleChange} name="vacc_office_location" value={this.state.vacc_office_location}>
                                         
                                         {vacclocation.map(vloc => { return (
                                                <option value={vloc.value}>
                                                {vloc.name}
                                                </option>
                                            );
                                          })}
                                    </select> 
                                        
                                    </div>
                                    
                                    <div className="form-group">
                                        <label htmlFor="exampleInputPassword1">Order Number</label>
                                        <input
                                            type="text"
                                            name="order_id"
                                            className="form-control"
                                            id="exampleInputPassword1"
                                            required
                                            placeholder="Order_id"
                                            value={this.state.order_id}
                                            onChange={this.handleChange}
                                        />
                                    </div>
                                    
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Batch Number</label>
                                        <input
                                            type="text"
                                            name="batch_no"
                                            className="form-control"
                                            required
                                            placeholder="batch_no"
                                            value={this.state.batch_no}
                                            onChange={this.handleChange}
                                        />
                                        
                                    </div>

                                    {/* <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Total Available Quantity</label>
                                        <input
                                            type="text"
                                            name="issue_Vaccine_quantity"
                                            className="form-control"
                                            required
                                            placeholder=" Available Quantity"
                                            value={this.state. issue_Vaccine_quantity}
                                            onChange={this.handleChange}
                                        />
                                        
                                    </div> */}

                                    {/* <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Consignment No</label>
                                        <input
                                            type="email"
                                            name="consignment_no"
                                            className="form-control"
                                            required
                                            placeholder="Consignment No"
                                            value={this.state.consignment_no}
                                            onChange={this.handleChange}
                                        />

                                     </div>   */}
                                   
                                    <div className="form-group">
                                        <label htmlFor="exampleInputEmail1">Issuing Quantity of Vaccine</label>
                                        <input
                                            type="text"
                                            name="issue_vaccine_quantity"
                                            className="form-control"
                                            required
                                            placeholder="issue_vaccine_quantity"
                                            value={this.state.issue_vaccine_quantity}
                                            onChange={this.handleChange}
                                        />

                                    </div>   
                                    <div>
                                        <br />
                                    </div>
                                    
                                    <button type="submit" className="btn btn-primary" >
                                        Submit
                                    </button>
                                    
                                    <button
                                        type="button"
                                        className="btn btn-secondary float-right"
                                        onClick={this.clearForm}
                                    >
                                        Cancel
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        );
    }
}

export default DistrictVaccAllocation;