import React, { Component } from 'react';
import { Link } from 'react-router-dom';
class ViewOrder extends Component {
 


    render() {
        return (
            
            <div>
                <h1>View Order Page</h1>
                <Link to={'/status'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Status
                    </button>
                </Link>
              <span> </span>
                <Link to={'/'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Cancelled Orders
                    </button>
                </Link>
                <span> </span>
                <Link to={'/viewallStatus'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     View all Orders
                    </button>
                </Link>
            </div>
        );
    }
}

export default ViewOrder;