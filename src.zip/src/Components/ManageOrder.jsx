import React, { Component } from 'react';
import { Link } from 'react-router-dom';
class ManageOrder extends Component {
 


    render() {
        return (
            
            <div>
                <h1>Manage Order Page</h1>
                <Link to={'/create_order'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Create Order
                    </button>
                </Link>
                <br></br>
                <span>  </span>
                <Link to={'/update_order'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Update Order
                    </button>
                </Link>
                <br></br>
                <span>  </span>
                <Link to={'/cancel_order'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     Cancel Order
                    </button>
                </Link>
                <br></br>
                <Link to={'/viewallStatus'}>
                    <button type="button" className="btn btn-primary mt-5 " >
                     View all Orders
                    </button>
                </Link>
            </div>
        );
    }
}

export default ManageOrder;