package vldms.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import vldms.models.Vaccination_office_distribution;

@Repository
public interface Vacc_Offi_Repo extends JpaRepository<Vaccination_office_distribution , Integer> 
{

}
