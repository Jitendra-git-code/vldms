package vldms.dao;



import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import vldms.models.Distribution_to_district_table;

@Repository
public interface StateRepo extends JpaRepository<Distribution_to_district_table,Integer>

{
	
}
