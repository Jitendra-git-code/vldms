package vldms.models;

public enum Status {
	
	 Pending,Approved,Reject,Cancelled
		
	}


