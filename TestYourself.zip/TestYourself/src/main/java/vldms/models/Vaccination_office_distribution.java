package vldms.models;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Vaccination_office_distribution 
{
	private int order_id;
	
	private int batch_no;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int consignment_no ;
	
	@Column(name = "vacc_office_location")
	@Enumerated(EnumType.STRING)
	private Office_loc  vacc_office_location;
	
	private int issue_vaccine_quantity;
	
	private Timestamp distribution_date;
	
	
	public Timestamp getDistribution_date() {
		return distribution_date;
	}

	public void setDistribution_date(Timestamp distribution_date) {
		this.distribution_date = distribution_date;
	}

	public int getOrder_id() 
	{
		return order_id;
	}
	
	public void setOrder_id(int order_id) 
	{
		this.order_id = order_id;
	}
	
	public int getBatch_no() 
	{
		return batch_no;
	}
	
	public void setBatch_no(int batch_no) 
	{
		this.batch_no = batch_no;
	}
	public int getConsignment_no() 
	{
		return consignment_no;
	}
	
	public void setConsignment_no(int consignment_no) 
	{
		this.consignment_no = consignment_no;
	}
	
	public Office_loc getVacc_office_location() 
	{
		return vacc_office_location;
	}
	
	public void setVacc_office_location(Office_loc vacc_office_location) 
	{
		this.vacc_office_location = vacc_office_location;
	}
	
	public int getIssue_vaccine_quantity() 
	{
		return issue_vaccine_quantity;
	}
	
	public void setIssue_vaccine_quantity(int issue_vaccine_quantity)
	{
		this.issue_vaccine_quantity = issue_vaccine_quantity;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Vaccination_office_distribution [order_id=");
		builder.append(order_id);
		builder.append(", batch_no=");
		builder.append(batch_no);
		builder.append(", consignment_no=");
		builder.append(consignment_no);
		builder.append(", vacc_office_location=");
		builder.append(vacc_office_location);
		builder.append(", issue_vaccine_quantity=");
		builder.append(issue_vaccine_quantity);
		builder.append(", distribution_date=");
		builder.append(distribution_date);
		builder.append("]");
		return builder.toString();
	}

	public Vaccination_office_distribution(int order_id, int batch_no, int consignment_no,
			Office_loc vacc_office_location, int issue_vaccine_quantity, Timestamp distribution_date) {
		super();
		this.order_id = order_id;
		this.batch_no = batch_no;
		this.consignment_no = consignment_no;
		this.vacc_office_location = vacc_office_location;
		this.issue_vaccine_quantity = issue_vaccine_quantity;
		this.distribution_date = distribution_date;
	}

	public Vaccination_office_distribution() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
