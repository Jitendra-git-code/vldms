package vldms.models;

public enum mrf_loaction {
	Pune,Hyderabad
}
