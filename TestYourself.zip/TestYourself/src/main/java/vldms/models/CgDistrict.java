package vldms.models;

public enum CgDistrict {
	
	
	Raipur_SVS,Bastar_RVS,Bilaspur_RVS,Surguja_RVS,Balod_DVS,bazar_Baloda,
	Balrampur_DVS,Bastar_DVS,Bemetara_DVS,Bijapur_DVS,Bilaspur_DVS,
	Dantewada_DVS,Dhamtari_DVS,Durg_DVS,Gariyaband_DVS,
	Champa_Janjgir,Jashpur_DVS,Kanker_DVS,Kawardha_DVS,Kondagaon_DVS,
	Korba_DVS,Koriya_DVS,Mahasamund_DVS,Mungeli_DVS,Narayanpur_DVS,Raigarh_DVS,
	Raipur_DVS,Rajnandgaon_DVS,Sukma_DVS,Surajpur_DVS,Surguja_DVS
	

}
