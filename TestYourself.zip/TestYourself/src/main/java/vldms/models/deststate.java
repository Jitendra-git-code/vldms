package vldms.models;

public enum deststate 
{
	AndhraPradesh,ArunachalPradesh,Assam
	,Bihar,Chhattisgarh,Goa,Gujarat,Haryana,
	Himachal_Pradesh,Jharkhand,Karnataka,Kerala,
	Madhya_Pradesh,Maharashtra,Manipur,Meghalaya,
	Mizoram,Nagaland,Odisha,Punjab,Rajasthan,
	Sikkim,TamilNadu,Telangana,Tripura,
	UttarPradesh,Uttarakhand,WestBengal

}
