package vldms.models;

public enum Companyname 
{
	Serum,BharatBiotech
}
