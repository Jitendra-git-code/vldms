package vldms.models;

public enum RegCenter {
	Amaravati,Itanagar,
	Dispur,Patna,Raipur,Panaji,Gandhinagar,
	Chandigarh,Shimla,Ranchi,Bengaluru,
	Thiruvananthapuram,Bhopal,Mumbai,Imphal,
	Shillong,Aizawl,Kohima,Bhubaneswar,
	Jaipur,Gangtok,Chennai,Hyderabad,
	Agartala,Lucknow,Dehradun,Kolkata

}
