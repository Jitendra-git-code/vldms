package vldms.models;

public enum Office_loc 
{
	Anantapur_UPHC,Chittoor_CHNC,East_Godavari_Inavilli,Guntur_Thallapalli,Krishna_PHC_Krithivenu,Nellore_PHC,Srikakulam_PHC,Visakhapatnam_PHC,
	Tirap_PHC,West_Kameng_PHC,East_Kameng_PHC,East_Siang_PHC,Lower_Subansiri_PHC,Upper_Subansiri_PHC,West_Siang_PHC,Lohit_PHC,Tawang_PHC,Changlang_PHC,
	Baksa_PHC,Barpeta_PHC,Biswanath_PHC,Bongaigaon_PHC,Cachar_PHC,Charaideo_PHC,Chirang_PHC,Darrang_PHC,Dhemaji_PHC,Goalpara_PHC,Golaghat_PHC,Hailakandi_PHC,Hojai_PHC,
	Araria_PHC,	Arwal_PHC,Aurangabad_PHC,Banka_PHC,Begusarai_PHC,Bhagalpur_PHC,Bhojpur_PHC,Buxar_PHC,Gaya_PHC,Madhubani_PHC,
	Balod_PHC,Bastar_PHC,Bijapur_PHC,Bilaspur_PHC,Durg_PHC,	Jashpur_PHC,Mahasamund_PHC,	Raipur_PHC,	Sukma_PHC,Surajpur_PHC,
	Goa_GMC,Goa_Bicholim_PHC,Ahmedabad_PHC,Gandhinagar_PHC,Vadodara_PHC,Anand_PHC,Rajkot_PHC,Amreli_PHC,Surat_PHC,Bharuch_PHC,
	Belgaum_PHC ,Bangalore_PHC,Gulbarga_PHC,Mysore_PHC 
}
