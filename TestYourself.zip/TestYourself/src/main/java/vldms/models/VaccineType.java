package vldms.models;

public enum VaccineType {
	Covishield,Covaxin
}
