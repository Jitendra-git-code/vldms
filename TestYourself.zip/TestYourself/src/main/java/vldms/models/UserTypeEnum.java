package vldms.models;

public enum UserTypeEnum 
{

	 MoHFW_Officer,Production_Officer ,
	  State_Store_Officer,District_Store_Officer ,Vaccination_Officer
	  
}
