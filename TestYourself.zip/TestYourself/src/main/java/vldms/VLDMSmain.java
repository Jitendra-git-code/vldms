package vldms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VLDMSmain {

	
	public static void main(String[] args) {
		SpringApplication.run(VLDMSmain.class, args);
	}

}
