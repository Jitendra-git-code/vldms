package MgnregaTest.TestYourself;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestYourselfApplicationTests {

	@Test
	void contextLoads() {
	}

}
